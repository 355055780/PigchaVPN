cd /Applications/pigcha_client.app/Contents/MacOS
sudo chown root:admin ProxyPrefManager
sudo chmod +s ProxyPrefManager
sudo chmod a+rx ProxyPrefManager