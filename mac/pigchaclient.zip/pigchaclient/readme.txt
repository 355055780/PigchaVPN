1.拷贝 pigcha_client.app 到 应用程序
2.打开terminal控制台 cd到当前目录，输入./app_permission.sh 并按提示输入密码
3.到启动台打开pigcha_client，如若出现 macOS无法验证此App不包含恶意软件，参考：https://blog.csdn.net/mhsszm/article/details/106116614
